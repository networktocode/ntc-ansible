===================================
Networktocode.Netauto Release Notes
===================================

.. contents:: Topics


v1.0.0
======

Release Summary
---------------

This is the first official release of an Ansible Collection for what was previously just a repo of ansible things called ntc-ansible.
