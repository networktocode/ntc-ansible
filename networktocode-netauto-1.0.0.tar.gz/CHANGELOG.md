# CHANGELOG

## [1.0.0]
- [#xx] Restructure to a Ansible Collection

## [0.9.4]

### Added
- [#236] Add support for **connection_args in ntc_config_command


## [0.9.3]

### Fixed
- [#262] Account for Ansible Versions beyond 2.9


## [0.9.2]

### Fixed
- [#256] Made setup.py work with python2.7 again
